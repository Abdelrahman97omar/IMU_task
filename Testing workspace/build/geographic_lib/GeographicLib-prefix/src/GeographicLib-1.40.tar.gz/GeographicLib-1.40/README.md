GeographicLib
=============

A C++ library for geographic projections.
